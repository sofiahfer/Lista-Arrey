/*Você tem um array com os nomes de quatro frutas ["Maçã", "Banana",
"Laranja", "Uva"]. Use um método para encontrar em qual posição está a
"Laranja". */

let frutas = ["Maçã", "Banana","Laranja", "Uva"]

console.log("Alaranja está na posição " + frutas.indexOf("Laranja"))