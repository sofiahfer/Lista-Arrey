/*Você tem um array com as cores ["Vermelho", "Verde", "Azul"]. Verifique se a
cor "Amarelo" está presente no array e imprima o resultado. */

let cores = ["Vermelho", "Verde", "Azul"]

console.log("A cor amarela está na array? "+ cores.includes("Amarelo"))